package main

import (
	"fmt"

	"github.com/hpcloud/tail"
)

// main
func main() {
	t, err := tail.TailFile("./test.txt", tail.Config{Follow: true})
	if err == nil {
		for line := range t.Lines {
			fmt.Println(line.Text)
		}
	}
}
